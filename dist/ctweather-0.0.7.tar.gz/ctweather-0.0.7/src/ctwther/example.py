
import wea

wea.test('오늘 뉴욕 날씨 어때?')

